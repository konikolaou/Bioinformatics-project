#include <stdio.h>

int main()
{
	char seq [1000];
	scanf("%s", seq);
	printf("the Sequence was: %s\n", seq);
}
