#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
	char seq [1000];
	int len;
	int i;
	scanf("%s", seq);
	len = strlen(seq);
	printf("the number is : %d\n", len);
	if( len < 5)
	{
		printf("no\n");
		exit(1);
	}
	for(i=0; i<len; i++)
	{
		if(seq[i] == 'F' && seq[i+1]== 'L' && seq[i+2]== 'A' && seq[i+3]== 'R' && seq[i+4]== 'E')
		{
			printf("found it at %d\n", i+1);
		}
	}
}
